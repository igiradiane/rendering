const express = require('express')
const app = express()
const port = 8000
const path = require('path');
// const about = require('./routes/about');
// utu tuboro tubiri dukurikira tuvuga dutya: 1
//ako join kavuzeko gafata iyo fota yitwa vies kakayigira constant kuburyo aho muri route dushaka guhamagara any page iri muriyo folder twandika izina ryiyo page instead of calling the whole folder path
//naho ako karimo engine ni ukuyibirako turi bukoreshe files zifite extension ya ejs

//app.set('views', path.join(__dirname, 'views'))
// app.set('view engine', 'ejs')
// app.use('', (req, res) => {
//         //urabonako hano instead of calling res.send dukoresh render 
//         res.render('index')
//     })
// app.use('/about', about)
//uku niko duhamagara html files zacu make sure kuzishyira muri folder,biriya byo hejuru nashyize muri comment better kubyihorera kereka nidukenera gukoresh ejs and routes uge uzi deckara nka gutya nabikze
app.get('', (req, res) => {
    res.sendFile(__dirname + '/views/index.html')
})
app.use('/about', (req, res) => {
        res.sendFile(__dirname + '/views/about.html')
    })
    // app.use('/about', (req, res) => {
    //     res.render('about')
    // })
app.listen(port, () => {
    console.log(`server is on...${port}`)
})