var express = require('express');
var router = express.Router();
const path = require('path');
const app = express()
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')
router.get('/', (req, res) => {
    res.render('about')
})
module.exports = router;